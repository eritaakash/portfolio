export const skills = [
    {
        title: 'MongoDB',
        icon: '/icons/mongodb-icon.svg'
    },
    {
        title: 'Express.js',
        icon: '/icons/express.svg'
    },
    {
        title: 'React',
        icon: '/icons/react-icon.svg'
    },
    {
        title: 'Node.js',
        icon: '/icons/node-icon.svg'
    },

    {
        title: 'Next.js',
        icon: '/icons/nextjs-icon.svg'
    },
    {
        title: 'Sass',
        icon: '/icons/sass-icon.svg'
    },
    {
        title: 'RN / Expo',
        icon: '/icons/react-native.svg'
    },
    {
        title: 'Electron',
        icon: '/icons/electron-icon.svg'
    },
    {
        title: 'Git & GitHub',
        icon: '/icons/git-icon.svg'
    }
]